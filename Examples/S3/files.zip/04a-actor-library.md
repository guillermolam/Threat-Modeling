[← 04 DFD Library](04-dfd-library.md) · [Contents](README.md) · [05 Other Model Types →](05-other-model-types.md)

# 04a · The Actor Library

> **Why this file exists.** Every earlier version of this model listed four or five actors and moved on. That's the most common way a threat model quietly under-covers a system: **the actor list bounds the threat set.** An actor you never drew produces threats you never enumerate — and the malicious insider is the actor teams omit most often, because modelling it means naming colleagues.

> 📕 **Provenance note.** No application code or live AWS configuration was supplied for this exercise. DFD components are treated as design-time modules and documented flows as entry points. Every risk below is therefore **theoretical** or **pending verification** — none is marked verified.

---

## 4a.1 Actors Determine Threats

> 📘 **Theory.** In [06 §6.2](06-stride.md), STRIDE-per-Element assigns Spoofing and Repudiation to external entities. But that's the *category*; the *content* depends entirely on who the entity is. An anonymous internet user can't abuse privileges they never had. An administrator can't be phished into privileges they already hold — they simply use them.
>
> Three questions distinguish actors, and each changes the threat set:
> 1. **Where do they sit?** Outside the trust boundary, inside it, or *astride* it (contractors, CI/CD)
> 2. **Human or machine?** Humans bring phishing, coercion, and social engineering; machines bring credential theft and supply-chain compromise
> 3. **What do they legitimately hold?** This is the one people skip — and it's the only one that matters for insiders

---

## 4a.2 How to Derive the Actor List (don't invent it)

> 📘 **Theory.** Actors are *discovered*, not brainstormed. Four mechanical sources, in order:
>
> | Source | What it yields |
> |---|---|
> | **Every interface / entry point on the DFD** | Whoever can reach it is an actor. An open listening endpoint with unknown clients is itself a finding ([04 §4.2](04-dfd-library.md)) |
> | **Every credential, key, and role that exists** | Each one implies a holder. "Who holds this?" is the question |
> | **Every trust boundary crossing** | Something crosses it; that something is an actor |
> | **The org chart and the vendor list** | Employees, contractors, MSPs, and partners with any access path |
>
> Then apply one closing question that catches what the four miss: **"who could do this today and we'd never know?"** That question is what surfaces insiders, because they don't appear at an interface — they're already inside it.

---

## 4a.3 The Master Actor Taxonomy

Reusable across any system. Use it as a checklist for *completeness*, then instantiate the ones that exist in yours.

```mermaid
flowchart TD
    A["<b>All Actors</b>"]
    A --> EXT["<b>External</b><br/>outside the trust boundary"]
    A --> AST["<b>Astride the boundary</b><br/>partial, delegated, or<br/>intermittent trust"]
    A --> INT["<b>Internal</b><br/>inside the trust boundary"]

    EXT --> E1["Anonymous / unauthenticated user"]
    EXT --> E2["Authenticated customer<br/><i>a free account is a low bar</i>"]
    EXT --> E3["Opportunistic scanner / bot"]
    EXT --> E4["Targeted external attacker"]
    EXT --> E5["Competitor"]
    EXT --> E6["Nation-state / APT"]
    EXT --> E7["Researcher / bug bounty"]
    EXT --> E8["Regulator / auditor"]

    AST --> A1["Contractor / temp staff"]
    AST --> A2["Vendor / SaaS partner"]
    AST --> A3["Managed service provider<br/><i>delegated admin</i>"]
    AST --> A4["CI/CD pipeline<br/><i>machine, high privilege</i>"]
    AST --> A5["Third-party library / dependency"]
    AST --> A6["Departing employee<br/><i>still has access</i>"]
    AST --> A7["Departed employee<br/><i>should not, but might</i>"]

    INT --> I1["Ordinary employee"]
    INT --> I2["Developer"]
    INT --> I3["Privileged admin / SRE"]
    INT --> I4["Data-privileged analyst"]
    INT --> I5["Support / helpdesk<br/><i>impersonation capability</i>"]
    INT --> I6["Security team member<br/><i>who watches the watchers</i>"]
    INT --> I7["Executive<br/><i>exception-granting authority</i>"]
    INT --> I8["Internal service account"]

    style A fill:#0d1117,color:#fff
    style INT fill:#5c1a1a,color:#fff
    style AST fill:#5c4a1a,color:#fff
```

> 💡 **Bridge — the two branches teams skip.** Most threat models cover the External branch well and the Internal branch barely. The **Astride** branch is skipped almost entirely, and it's where two of our findings live: F-09 (the CI/CD pipeline, A4) and the partner integration that appears in our L0 diagram and nowhere else (A2). An actor that isn't clearly "us" or "them" tends to end up modelled as neither.

### Cross-cutting dimension: motivation

The same position produces different behaviour depending on why:

| Motivation | Behaviour signature |
|---|---|
| **Financial** | Bulk exfiltration, saleable data, ransomware |
| **Grievance** | Destruction, sabotage, targeted embarrassment; often timed to a termination |
| **Ideological** | Selective leaking to press or activists |
| **Coerced** | Blackmail or bribery; behaves normally then acts once |
| **Curiosity** | Browsing records with no exfiltration — still a breach, often a *reportable* one |
| **Negligent** | **No malice at all.** Same DFD position, same access, accidental outcome |

> 📘 **Model the negligent insider too.** They occupy the identical position on the diagram and produce many of the same impacts. Crucially, most controls that catch negligence (least privilege, four-eyes, alerting) also constrain malice — so modelling them together is efficient. Where they diverge: negligence is *detectable by pattern*, malice actively *evades* detection.

---

## 4a.4 🏢 Our Actor Register

IDs follow the `EI-NNN` external-interactor convention so this drops into the skill's P2 `dfd_elements` schema.

| ID | Actor | Class | Human/Machine | Trust | Legitimately holds | Present in our system? |
|---|---|---|---|---|---|---|
| **EI-001** | Anonymous internet user | External | H | Untrusted | Nothing | ✅ Yes — public prefix |
| **EI-002** | Authenticated customer | External | H | Low | Own avatar upload; own records | ✅ Yes — free registration |
| **EI-003** | Opportunistic scanner / bot | External | M | Untrusted | Nothing | ✅ Yes — continuous, passive |
| **EI-004** | Targeted external attacker | External | H | Untrusted | Nothing | ⚠️ Assume yes |
| **EI-005** | Bug bounty researcher | External | H | Untrusted | Nothing | ❌ No programme exists |
| **EI-006** | Regulator / external auditor | External | H | Conditional | Evidence on request | ⚠️ Not yet modelled |
| **EI-010** | CI/CD pipeline (GitHub Actions) | Astride | **M** | **High — unverified scope** | `PutBucketPolicy` on *(scope unknown, S3)* | ✅ Yes — **F-09** |
| **EI-011** | Partner / vendor integration | Astride | M | Medium | Writes to a partner prefix | ✅ Yes — **never decomposed** |
| **EI-012** | Contractor / temp staff | Astride | H | Variable | Whatever they were granted | ⚠️ Unknown — no register exists |
| **EI-013** | Managed service provider | Astride | H | Potentially high | Delegated admin | ❌ None today |
| **EI-014** | Third-party dependency (image parser) | Astride | M | Implicit | Executes in the reader's context | ✅ Yes — see **E-c** in [06](06-stride.md) |
| **EI-015** | Departing / departed employee | Astride | H | Should be none | **No offboarding process verified** | ⚠️ Unknown |
| **EI-020** | Developer | Internal | H | Medium | Repo write; can author IaC | ✅ Yes |
| **EI-021** | Privileged admin / SRE | Internal | H | **Total** | **Root — no roles exist (S6)** | ✅ Yes — **the dominant insider risk** |
| **EI-022** | Data-privileged analyst | Internal | H | Medium-high | Legitimate bulk PII read | ✅ Yes |
| **EI-023** | Support / helpdesk | Internal | H | Medium | Possibly customer impersonation | ⚠️ Unknown — not modelled |
| **EI-024** | Security team member | Internal | H | High | Log and config access | ✅ Yes — see §4a.6 |
| **EI-025** | Executive | Internal | H | Authority, not access | Can grant exceptions to controls | ⚠️ Not modelled |
| **EI-026** | Internal service account | Internal | M | Variable | Analytics reader role | ✅ Yes |

**Coverage:** 8 of 19 candidate actors were in the original model. **Six are unknown or unmodelled** — each is an open item for [B](B-traceability-log.md).

---

## 4a.5 Deep Dive: The Malicious Insider

### "Insider" is not one actor

> 📘 **Theory — the single most useful reframe here.** Treating "malicious insider" as one entry produces one generic finding and one generic control ("least privilege"). Decomposing by **what they legitimately hold** produces distinct threats with distinct detection strategies, because each sub-type's malicious behaviour is *camouflaged by a different legitimate activity*.

| Sub-type | Legitimately holds | Malicious use | Camouflaged by |
|---|---|---|---|
| **IN-1 · Privileged admin** | Root / full IAM | Read everything; disable logging first | Routine ops work |
| **IN-2 · Developer** | Repo + pipeline write | Ship a policy change that opens the bucket | Normal deploys |
| **IN-3 · Data analyst** | Bulk PII read, by job description | Exfiltrate; browse individuals | **Their actual job** |
| **IN-4 · Support / helpdesk** | Customer impersonation | Access a specific person's records | Ticket handling |
| **IN-5 · Security team** | Logs, config, audit | Alter evidence; disable a detection | Security work |
| **IN-6 · Departing employee** | Everything, until offboarding completes | Bulk copy before leaving | Normal work, elevated volume |
| **IN-7 · Coerced insider** | Whatever their role grants | One targeted action, then normal | Everything |
| **IN-8 · Negligent insider** | Whatever their role grants | *(no intent)* — misconfigures, pastes a key, emails an export | Genuinely being helpful |

### Why insiders defeat the controls we've specified

This is uncomfortable and worth stating plainly. Against **EI-021** (privileged admin, currently root):

| Control from [10](10-security-requirements.md) | Stops an external attacker? | Stops this insider? | Why |
|---|---|---|---|
| Block Public Access | ✅ | ❌ | They can turn it off |
| Deny anonymous `ListBucket` | ✅ | ❌ | They're authenticated |
| SSE-KMS encryption | ✅ | ❌ | They hold decrypt rights |
| TLS enforcement | ✅ | ❌ | Irrelevant to an authorized read |
| WAF / rate limiting | ✅ | ❌ | They don't come through the CDN |
| CloudTrail data events | ✅ detect | ⚠️ **partial** | Records it — unless they disable it first |
| Versioning / Object Lock | ✅ | ⚠️ Governance mode: no. Compliance mode: yes |
| Separation of duties | n/a | ✅ | **The first control that actually bites** |
| PIM / just-in-time access | n/a | ✅ | Removes standing privilege |
| Behavioural anomaly detection | ⚠️ | ✅ | Volume and pattern, not authorization |
| Immutable logs in a separate account | ⚠️ | ✅ | They can't reach the evidence |

> 💡 **Bridge — the finding this produces.** Of eleven controls, **five do nothing** against a privileged insider and two only partially help. Every one of the five is a *perimeter* or *authorization* control, and an insider is already past both. The controls that work are all **structural**: split the privilege, remove it when unused, put the evidence somewhere the actor can't reach, and detect on behaviour rather than permission.
>
> This is precisely why S6 (root-only AWS access) is more serious than it first appears. It isn't just "we haven't set up IAM yet" — it means **every single control in our register that depends on separation of duties currently has nothing to separate.**

### 🏢 The insider DFD

The same system drawn from inside the boundary. Note how few boundaries the insider crosses — that's the entire point.

```mermaid
flowchart LR
    subgraph EXT["🔴 Internet — where our controls point"]
        Att(("👤 External<br/>attacker"))
        WAF{{"WAF"}}
    end

    subgraph AWS["🟢 AWS Account — 'trusted'"]
        subgraph NoB[" ⚠ NO INTERNAL TRUST BOUNDARY EXISTS "]
            Admin(("👤 IN-1<br/>Privileged admin<br/>ROOT"))
            Dev(("👤 IN-2<br/>Developer"))
            Analyst(("👤 IN-3<br/>Data analyst"))
            Sec(("👤 IN-5<br/>Security team"))
        end
        S3Data[("Customer PII")]
        S3Ugc[("UGC")]
        Policy["Bucket policy<br/>+ BPA config"]
        CT["CloudTrail"]
        LOGS[("Log bucket<br/>⚠ same account")]
    end

    Att -->|"blocked / logged"| WAF -.->|"must defeat<br/>every control"| S3Data
    Admin -->|"▶ direct read · authorized · normal"| S3Data
    Admin -->|"▶ can disable"| CT
    Admin -->|"▶ can rewrite"| Policy
    Admin -->|"▶ can alter"| LOGS
    Dev -->|"▶ via pipeline · looks like a deploy"| Policy
    Analyst -->|"▶ bulk read · IS their job"| S3Data
    Sec -->|"▶ can suppress a detection"| CT

    style EXT fill:#3d1f1f,color:#fff
    style AWS fill:#1f3d2b,color:#fff
    style NoB fill:#5c1a1a,color:#fff
    style LOGS fill:#5c1a1a,color:#fff
```

**Read the arrow counts.** The external attacker has one path and must defeat every control on it. The admin has four paths, crosses no boundary, and one of those paths reaches the evidence itself.

### 🏢 Insider-specific STRIDE

Extends the component-based pass in [06 §6.7](06-stride.md).

| | Insider threats |
|---|---|
| **S**poofing | **IN-S1:** Support staff use an impersonation feature to act as a specific customer, leaving log entries attributed to that customer. **IN-S2:** An admin assumes a service role, so the action is attributed to the service, not the person. **IN-S3:** A departing employee uses a shared or service credential that maps to no individual. |
| **T**ampering | **IN-T1:** A developer ships an IaC change that widens the bucket policy; it arrives through the legitimate path and looks like a deploy (**F-09** amplifies this). **IN-T2:** An admin selectively alters a small number of records — no dramatic event to trigger investigation, and with versioning off, no earlier copy to compare (**F-11**). **IN-T3:** A security team member modifies a Config rule so a misconfiguration stops being reported. |
| **R**epudiation | **IN-R1:** An admin disables CloudTrail data events *before* acting and re-enables after. **IN-R2:** The log bucket is in the **same account**, so a sufficiently privileged insider can reach the evidence. **IN-R3:** No per-person attribution exists at all today — everything is root (**S6**), so *every* action is unattributable. |
| **I**nformation Disclosure | **IN-I1:** An analyst's bulk PII read is indistinguishable from their job. **IN-I2:** An admin reads records with no business need and no ticket — a reportable breach with no technical indicator. **IN-I3:** A departing employee copies exports over weeks at normal volume. **IN-I4:** An insider shares a long-lived presigned URL externally, converting their authorized access into anonymous access **that survives their offboarding**. |
| **D**enial of Service | **IN-D1:** An admin schedules KMS key deletion — permanent, and one API call. **IN-D2:** Mass delete with versioning off. **IN-D3:** A grievance-motivated insider times destruction to their last day. |
| **E**levation of Privilege | **IN-E1:** A developer adds a permission to their own role via IaC — visible in the diff, invisible if nobody reviews it. **IN-E2:** `iam:PassRole` + `PutBucketPolicy` self-grant (**E-a**). **IN-E3:** A "temporary" permission granted to unblock a deploy is never removed (**E-e**). |

> 📘 **Catalog grounding.** The insider primitive is **CAPEC-122 (Privilege Abuse)** — and its own metadata makes the argument better than prose can: **severity Medium, likelihood High, skills required Low, resources required None.** The prerequisite is simply an account with more privilege than it needs. Related ATT&CK: **Valid Accounts** (the technique that *defines* insider tradecraft — no exploit, no malware, just credentials), **Data from Cloud Storage**, **Data from Information Repositories**, **Exfiltration Over Web Service**, and **Account Manipulation** for the persistence variant.

> 💡 **Bridge.** Sit with "skills: Low, resources: None." Every other attack tree in [08](08-attack-trees-capec.md) has leaves annotated with cost and skill, and the insider tree's leaves are all *free*. There is no attacker-capability barrier to overcome — which means the **only** variable left is motivation, and motivation is the one factor you cannot engineer away. That's why insider controls are structural rather than technical.

### 🏢 Attack Tree 5 — Insider exfiltration

```mermaid
flowchart TD
    G5["<b>GOAL</b><br/>Insider exfiltrates customer data<br/>without being detected"]
    G5 --> N1["1 · Obtain the data<br/><i>usually already authorized</i>"]
    G5 --> N2["2 · Avoid or defeat detection"]
    G5 --> N3["3 · Move it out"]
    G5 --> N4["4 · Retain access after leaving"]

    N1 --> N11["1.1 Use existing legitimate access<br/><i>skill: none · CAPEC-122</i>"]
    N1 --> N12["1.2 Self-grant via IaC change"]
    N1 --> N13["1.3 Assume a service role<br/><i>attribution shifts to the service</i>"]
    N1 --> N14["1.4 Use a shared/unattributed credential"]

    N2 --> N21["2.1 Disable data-event logging first<br/><i>then re-enable</i>"]
    N2 --> N22["2.2 Alter logs — same account (⚠)"]
    N2 --> N23["2.3 Stay under volume thresholds<br/><i>slow exfiltration over weeks</i>"]
    N2 --> N24["2.4 Hide inside legitimate job activity<br/><i>the analyst problem</i>"]

    N3 --> N31["3.1 Generate a long-TTL presigned URL<br/><i>converts authorized access to anonymous</i>"]
    N3 --> N32["3.2 Copy to a personal cloud account"]
    N3 --> N33["3.3 Email or message an export"]
    N3 --> N34["3.4 Physical/endpoint copy"]

    N4 --> N41["4.1 Presigned URL outliving offboarding"]
    N4 --> N42["4.2 Add a personal key to a role<br/><i>ATT&CK Account Manipulation</i>"]
    N4 --> N43["4.3 Leave a cross-account trust in place"]

    style G5 fill:#5c1a1a,color:#fff
    style N11 fill:#8b1a1a,color:#fff
    style N31 fill:#8b1a1a,color:#fff
```

> 💡 **Bridge — 3.1 and 4.1 are the same leaf, and it's the nastiest one here.** A presigned URL generated by an authorized insider **converts their temporary, attributable, revocable access into permanent, anonymous, unrevocable access.** Removing the person's account does not invalidate the URL. It's the one insider technique that survives offboarding cleanly, requires no ongoing access, and leaves an audit trail showing only a legitimate authorized action. If you take one control from this file, make it TTL limits on presigned URL generation.

---

## 4a.6 Who Watches the Watchers (EI-024 / IN-5)

> 📘 **Theory.** The security team is an actor. They hold log access, config access, and detection tuning — the exact capabilities needed to make an incident invisible. Most threat models omit them because the model is *written by* them.

**Structural mitigations, in increasing order of cost:**

1. **Log destination in a separate AWS account** with a distinct access path — already required by LOG-2 in [10](10-security-requirements.md), and it does double duty here
2. **Detection-tuning changes are themselves logged and reviewed** by someone outside the security team
3. **Audit role without `GetObject`** ([12 §12.5](12-identity-iam-entra.md)) — verify configuration without reading data
4. **Dual control on log-retention and Config-rule changes**
5. **Periodic external review** — the reason external auditors (EI-006) exist as an actor at all

---

## 4a.7 Controls That Actually Constrain Insiders

Ordered by effectiveness against **IN-1 through IN-8**, not by ease.

| # | Control | Which sub-types it constrains | Cost |
|---|---|---|---|
| 1 | **Eliminate standing privilege** — PIM/JIT with approval, per [12 §12.7](12-identity-iam-entra.md) | IN-1, IN-2, IN-5, IN-6 | Medium |
| 2 | **Separation of duties** — author ≠ approver ≠ auditor | IN-1, IN-2, IN-5 | Medium |
| 3 | **Immutable logs in a separate account** | All — protects the evidence itself | Low |
| 4 | **Presigned URL TTL ceiling, enforced server-side** | IN-1, IN-3, IN-6 — closes leaf 3.1/4.1 | **Low** |
| 5 | **Behavioural anomaly detection** — volume, timing, first-time-access | IN-3, IN-6, IN-7 (the only ones that catch "authorized but wrong") | Medium |
| 6 | **Automated offboarding with verification** | IN-6 | Low |
| 7 | **Four-eyes on IaC touching policy or IAM** | IN-2 | Low |
| 8 | **Access reviews every 90 days** | IN-6, IN-8, and permission creep generally | Low |
| 9 | **Object Lock in Compliance mode** | IN-1 destruction — *but see the erasure conflict in [13 §13.3](13-hardening-deep-dive.md)* | Medium |
| 10 | **Data minimization** — export fewer fields | IN-3 — reduces what bulk access is even worth | Medium |
| 11 | **Purpose logging** — require a ticket reference for PII access | IN-1, IN-2, IN-3 — converts "was this authorized?" into "was this *justified*?" | High |

> 💡 **Bridge — #11 is the one that changes the question.** Every other control asks *"was this permitted?"* Purpose logging asks *"was there a reason?"* For IN-3 — the analyst whose job is bulk PII access — it is the **only** control on this list that can distinguish legitimate work from exfiltration, because the access pattern is identical either way. It's expensive and culturally difficult, which is why it's last. It's also why regulated industries mandate it.

---

## 4a.8 Actor × Asset Matrix

Trike-style ([15](15-methodology-comparison.md)), extended to insiders. **C**reate **R**ead **U**pdate **D**elete. ⚠ marks a finding.

| Actor ↓ / Asset → | Public assets | UGC | Customer PII | Bucket policy | Logs | KMS key |
|---|---|---|---|---|---|---|
| EI-001 Anonymous | R | R | **⚠ R** | — | — | — |
| EI-002 Auth. customer | R | C,R *(own)* | — | — | — | — |
| EI-010 CI/CD | — | — | — | **⚠ CRUD** | — | — |
| EI-011 Partner | — | — | — | — | — | — |
| EI-021 Admin (IN-1) | CRUD | CRUD | **⚠ CRUD** | **⚠ CRUD** | **⚠ CRUD** | **⚠ CRUD** |
| EI-022 Analyst (IN-3) | — | — | **R (bulk, by design)** | — | — | — |
| EI-020 Developer (IN-2) | — | — | — | **⚠ U via pipeline** | — | — |
| EI-024 Security (IN-5) | — | — | — | R | **⚠ CRUD** | — |
| EI-026 Service account | — | R | R | — | — | — |

**Target state:** no row should read CRUD across every column. EI-021 currently does, because no roles exist (S6). Compare against the target design in [12 §12.5](12-identity-iam-entra.md), where that row splits across four PIM-gated roles.

---

## 4a.9 Session Questions for Insider Coverage

Add to the CTM subject list in [14 §14.5](14-continuous-threat-modeling.md). Ask these as discussion openers, not checkboxes.

- Who could read every customer record right now, and would we know?
- Who could turn off logging, and would that itself be logged **somewhere they can't reach**?
- If someone resigned this afternoon, what would they still have access to tomorrow?
- Which access is *legitimate but unmonitored* — where the pattern is identical whether the intent is good or bad?
- Who approves the approver?
- Which of our detections could be disabled by the person the detection is watching?
- What can a support agent see or do on behalf of a customer, and is it recorded against **them** or the customer?
- Which credentials map to no individual person?
- What would a bulk export look like in our logs — and have we ever actually looked at one?

> 📘 **A facilitation note.** These questions name colleagues, which makes them uncomfortable — see the blame-free-zone guidance in [03 §3.3](03-session-facilitation.md). The framing that works: *"this is about not putting our own people in a position where a single mistake or a single bad day becomes a company-ending event."* Insider controls protect the insider as much as the data — an admin who **cannot** unilaterally exfiltrate also cannot be **suspected** of it.

---

## 4a.10 Open Items From This Analysis

| # | Item | Type | Owner |
|---|---|---|---|
| A-1 | Six actors unknown or unmodelled (EI-006, 012, 013, 015, 023, 025) | Coverage gap | Cloud Security |
| A-2 | No offboarding process verified (EI-015) | Verification | HR + Platform Eng |
| A-3 | Log bucket is in the same account as the data | **Design finding** | Cloud Security |
| A-4 | No presigned URL TTL ceiling enforced server-side | **Design finding** | App Eng |
| A-5 | Support impersonation capability unknown (EI-023) | Verification | App Eng |
| A-6 | Partner integration (EI-011) still never decomposed | Coverage gap | Platform Eng |
| A-7 | No behavioural anomaly detection on bulk PII read | **Design finding** | Cloud Security |
| A-8 | No purpose/justification logging for PII access | Design decision | DPO + Cloud Security |

All eight are **theoretical or pending** — no application code or live AWS configuration was supplied to verify any of them.

---

[← 04 DFD Library](04-dfd-library.md) · [Contents](README.md) · [05 Other Model Types →](05-other-model-types.md)
