[← 03 Session Facilitation](03-session-facilitation.md) · [Contents](README.md) · [04a Actor Library →](04a-actor-library.md)

# 04 · The DFD Library

Fourteen diagrams, from context down to internal logic, with full annotation tables. This is the reference file — everything else in the guide points back here.

---

## 4.1 Why DFDs Specifically

> 📘 **Theory.** DFDs came out of structured analysis in the 1970s (Gane & Sarson; Yourdon & DeMarco) and became the default threat-modeling notation because of one property: **simplicity**. A small, fixed symbol set means an entire mixed team — developers, testers, product owners, non-technical stakeholders — can read the same diagram and argue about the same system. That shared understanding *is* the deliverable. A more precise architectural diagram that only three people can read is worse for this purpose.

**What a DFD gives you:**
- A high-level view of the components, connectors, and actors that matter
- A high-level view of the data flows between them
- Deliberately *less* technical detail than an architecture diagram, so it stays readable
- A shared artifact to communicate ideas within the team
- Input into every subsequent threat-modeling step

**What a DFD cannot give you:** ordering in time. See [05 · Other Model Types](05-other-model-types.md) — this limitation cost us a real finding.

---

## 4.2 Notation Standard for This Guide

> 📘 **Theory: the five core types.** Most practitioners standardize on exactly five component types, and the discipline of *not adding more* is what keeps DFDs readable:
>
> | Type | Symbol convention | Meaning |
> |---|---|---|
> | **Process** | Circle or rounded rectangle | Applications/components that apply logic or change data — the "core" of the diagram |
> | **Data Store** | Two parallel lines, or a cylinder | Where information is held: database, file, bucket, queue, shared memory |
> | **Interactor / External Entity** | Rectangle | A person or system outside the scope that interacts with it |
> | **Data Flow** | Arrow | Data moving from source to destination. Two arrows (or a double-headed arrow) for bidirectional |
> | **Trust Boundary** | Dotted line or dotted rectangle | Where the level of trust changes |

> 📘 **Theory: useful non-standard extensions.** Tarandach & Coles advocate a few additions that earn their keep. Use them *consistently* or not at all:
>
> | Extension | Why it matters |
> |---|---|
> | **Initiator mark** | Shows *which endpoint starts* the flow. Without it a diagram is ambiguous, and the threat picture genuinely differs depending on the answer |
> | **Interface element** | A defined connection point (port/endpoint) whose clients aren't known at design time. An open listening endpoint is a major source of architectural risk and deserves to be visible |
> | **Container** | An element that contains other elements and flows — reduces busyness at the context layer |
> | **Block** | Something that selectively alters a flow: host firewall, WAF, physical device |
> | **Actor** | Distinguishes a *human* user from a system external entity |

**Our house rules for this guide** (decide these before you draw, and write them down — that decision is itself a best practice):

```
▶init X    = X initiates this flow
[iface]    = interface/listening endpoint
{{ }}      = block element (WAF, firewall)
Subgraphs  = trust boundaries
Red fill   = element with an open finding
Dotted arrow = logging/telemetry flow (not primary data)
```

---

## 4.2b Rendering True DFD Shapes in Mermaid

A practical problem: the classic DFD symbol set (circle for process, open-ended rectangle for data store, stick figure for actor) doesn't map cleanly onto Mermaid's original node syntax. There are three approaches, and only two of them are portable.

### Portability matrix — check this before choosing

| Approach | Syntax | Renders in mermaid.live | Renders in GitHub / VS Code / Obsidian / static site generators | Verdict |
|---|---|---|---|---|
| **Classic node syntax** | `A[Rect]` `A((Circle))` `A[(Cylinder)]` | ✅ | ✅ | **Safest.** Universally supported |
| **Expanded shapes (v11.3.0+)** | `A@{ shape: cyl }` | ✅ | ✅ *if the renderer ships Mermaid ≥ 11.3* | **Recommended.** Real DFD semantics, plain text, no assets |
| **Icon shapes** | `A@{ icon: "fa:user" }` | ✅ | ❌ | **Avoid in shared docs** |

> ⚠️ **Why icons fail elsewhere.** Icon shapes require the icon pack to be **registered** in the renderer first (`mermaid.registerIconPacks(...)`), and the older inline form (`fa:fa-car` inside a label) is limited to Font Awesome — an upstream Mermaid.js constraint, not a tooling gap. Most Markdown pipelines register nothing, so the node renders empty or errors out. Icons also frequently don't survive PNG/SVG export. Use them in a live editor for a presentation if you like; don't commit them to a repo other people read.

### The DFD element → Mermaid shape mapping

Use this as the notation standard. The middle column is the portable expanded syntax; the right column is the always-works fallback.

| DFD element | Expanded syntax (v11.3+) | Classic fallback | Notes |
|---|---|---|---|
| **Process** *(applies logic)* | `A@{ shape: circle }` | `A((Process))` | Circle is the traditional DFD process symbol |
| **Process** *(pragmatic alt.)* | `A@{ shape: rounded }` | `A(Process)` | Rounded rectangle; easier to fit long labels |
| **Complex process / Container** | `A@{ shape: subproc }` | `A[[Container]]` | Framed rectangle — signals "there are elements inside this" |
| **External entity / Interactor** | `A@{ shape: rect }` | `A[External]` | Plain rectangle, per convention |
| **Data store** | `A@{ shape: cyl }` | `A[(Data Store)]` | Cylinder — the database convention |
| **Data store** *(classic DFD look)* | `A@{ shape: bow-rect }` | *(none)* | "Stored data" shape, closer to the open-ended rectangle |
| **Data store** *(disk/bulk)* | `A@{ shape: lin-cyl }` | *(none)* | Lined cylinder — useful to distinguish a log/archive store |
| **Decision / condition** | `A@{ shape: diam }` | `A{Decision}` | Policy evaluation points |
| **Block element** *(WAF, firewall)* | `A@{ shape: hex }` | `A{{WAF}}` | Something that selectively alters a flow |
| **Interface / port** | `A@{ shape: stadium }` | `A([:443])` | An exposed listening endpoint |
| **Document / report output** | `A@{ shape: doc }` | *(none)* | Useful for evidence and report artifacts |
| **Manual step** | `A@{ shape: manual-input }` | *(none)* | Human-in-the-loop steps — e.g. break-glass approval |
| **Trust boundary** | `subgraph` + `style` | same | Unchanged; subgraphs are the only real option |
| **Actor (human)** | *see below* | `A((👤 User))` | **No native stick figure exists in flowchart** |

### The actor problem, and three honest workarounds

Mermaid's **flowchart** has no stick-figure actor. Options, in order of preference for a shared document:

1. **Circle + emoji + label** — `User@{ shape: circle, label: "👤 Customer" }`. Portable everywhere, reads unambiguously, costs nothing.
2. **Use a `sequenceDiagram` where the actor matters most.** Sequence diagrams *do* have a native `actor` keyword that renders a real stick figure. Since you need sequence diagrams anyway for time-ordered analysis ([05](05-other-model-types.md)), this is where your actors can look correct.
3. **Icon shape** — `User@{ icon: "fa:user", form: "circle" }`. Looks best, works only in mermaid.live and licensed editors. Fine for a slide, not for the repo.

> 💡 **Bridge — why this matters more than aesthetics.** The point of distinguishing an actor from an external system isn't decoration: humans are susceptible to a different threat set. In [06 §6.2](06-stride.md), external entities draw Spoofing and Repudiation, and a *human* actor additionally brings phishing, social engineering, and credential reuse into scope. If your notation can't tell a person from a service, your STRIDE pass will quietly under-cover the human paths. Emoji-in-a-circle is an ugly solution to a real analytical problem — but it *is* a solution.

### Demonstration: L0 rendered with true DFD shapes

Same content as §4.5, drawn with the expanded syntax so you can compare. **This requires Mermaid ≥ 11.3** — if it renders as an error for you, your renderer is older, and the rest of this guide's diagrams (which use classic syntax) will still work fine.

```mermaid
flowchart LR
    User@{ shape: circle, label: "👤 Anonymous
Internet User" }
    Customer@{ shape: circle, label: "👤 Authenticated
Customer" }
    CICD@{ shape: rect, label: "CI/CD Pipeline
(external system)" }
    Partner@{ shape: rect, label: "Partner / Vendor
(external system)" }

    IF@{ shape: stadium, label: "[iface] :443 HTTPS" }
    System@{ shape: subproc, label: "S3-Based Customer Data
& Asset Storage System" }
    Logs@{ shape: lin-cyl, label: "Audit & Access Logs" }
    Report@{ shape: doc, label: "Compliance Evidence" }

    User -->|"▶init User · public assets"| IF
    Customer -->|"▶init Customer · avatar upload"| IF
    CICD -->|"▶init CICD · policy deploy"| IF
    Partner -->|"▶init Partner · prefix write"| IF
    IF --> System
    System -.->|"telemetry"| Logs
    Logs --> Report

    style System fill:#1f3d2b,color:#fff
```

Note what the shapes now carry semantically without a legend: circles are people, plain rectangles are external systems, the framed rectangle says "decompose me," the stadium is an exposed port, the lined cylinder is a distinct log store, and the document shape is an output artifact rather than a data store.

> 📘 **Recommendation for this guide.** The 14 diagrams in §4.5–4.16 stay in **classic syntax** deliberately, so they render for every reader regardless of Mermaid version. If your team's renderer is on ≥ 11.3, converting them using the mapping table above is a mechanical change and worth doing — the semantic gain is real. Verify the exact shape names against the current Mermaid flowchart documentation before a bulk conversion; the expanded shape set is newer than the classic syntax and the names have moved between releases.

---

## 4.3 Metadata: What to Annotate

> 📘 **Theory.** A diagram alone is not a model. Each element needs annotations — either on the diagram or in an accompanying table keyed by label. **Garbage in, garbage out**: the analysis is only as good as the metadata. Note also that it's better to have an element full of question marks than one that looks complete but contains known-wrong information.

**For processes/elements:** name · owning team · privilege level it runs at · language/runtime · signed? · production-only or also dev/test? · compile/hardening flags · does a sequence diagram exist for it?

**For data stores:** storage type · data type & format · sensitivity/classification · protections on the store itself (encryption at rest) · replication · backup (and whether the backup has *weaker* controls — a classic gap)

**For data flows:** channel type (network vs. IPC) · protocol(s) · authentication on the channel (mutual TLS? client certs?) · data classification carried · order of operations · **initiator**

**For interfaces:** port · channel/mechanism · protocols offered · access controls on inbound connections · externally exposed?

**For trust boundaries:** description of the symmetric trust relationship, or — if trust is *asymmetric* (A trusts B but B doesn't trust A) — don't use a boundary at all; annotate the flow instead.

---

## 4.4 How to Build One (Step Order)

> 📘 **Theory.** There's no single right order, but this sequence works:
> 1. **Understand the system** with the team before drawing anything
> 2. **Draw the main Processes** — the things that actually *do* something
> 3. **Draw the Interactors** — who/what talks to it
> 4. **Draw the Data Stores** — where data lands
> 5. **Draw the Trust Boundaries** — every component must sit inside one
> 6. **Draw the Connectors** — only between things that actually communicate, with correct direction
>
> **Stopping rule (from Trike, the crispest in the field):** decompose *until no processes cross trust boundaries.*

---

# THE DIAGRAMS

## 4.5 L0 — Context Diagram

The whole system as one box. This is what you open the session with.

```mermaid
flowchart LR
    User(("Anonymous<br/>Internet User"))
    Customer(("Authenticated<br/>Customer"))
    Analyst(("Internal<br/>Analyst"))
    CICD(("CI/CD<br/>Pipeline"))
    Sec(("Security<br/>Monitoring"))
    Partner(("Partner /<br/>Vendor"))

    System["S3-Based Customer Data<br/>& Asset Storage System"]

    User -->|"HTTPS GET · public assets"| System
    Customer -->|"presigned PUT · avatar upload"| System
    Analyst -->|"read exports"| System
    CICD -->|"deploy policy/config"| System
    Partner -->|"writes to partner prefix"| System
    System -->|"logs, findings, evidence"| Sec

    style System fill:#1f3d2b,color:#fff
```

| Element | Type | Notes |
|---|---|---|
| Anonymous Internet User | Actor (untrusted) | No credential. Volume unbounded. |
| Authenticated Customer | Actor (semi-trusted) | Any registered account — a low bar. Enabler for T18. |
| Internal Analyst | Actor (trusted) | Reads PII exports. |
| CI/CD Pipeline | External entity (machine) | **Holds the credential that can rewrite the control itself.** |
| Partner / Vendor | External entity (3rd party) | Inherited risk — needs its own threat model. |

---

## 4.6 L1-A — Scenario A, Path 1: Direct S3 Access (no CDN)

The intentional-public case with the bucket exposed directly.

```mermaid
flowchart LR
    subgraph TB1["🔴 TRUST BOUNDARY: Internet (untrusted)"]
        User(("Anonymous<br/>User"))
    end

    subgraph TB2["🟢 TRUST BOUNDARY: AWS Account (trusted)"]
        IF1["[iface] S3 REST endpoint<br/>:443 · public"]
        S3[("S3 Bucket<br/>MIXED CLASSIFICATION")]
        CT["CloudTrail"]
        LOGS[("Log Bucket")]
    end

    User -->|"▶init User · HTTPS · GetObject"| IF1
    User -->|"▶init User · HTTPS · ListBucket ⚠"| IF1
    IF1 --> S3
    S3 -.->|"data events"| CT
    S3 -.->|"server access logs"| LOGS

    style TB1 fill:#3d1f1f,color:#fff
    style TB2 fill:#1f3d2b,color:#fff
    style S3 fill:#5c1a1a,color:#fff
```

**Annotations**

| Element | Metadata |
|---|---|
| S3 Bucket | Type: object store · Data: **mixed** (public assets + PII + UGC) · Classification: worst-case regulated · At rest: SSE with AWS-managed key (no controllable key policy) · Versioning: **OFF** · Replication: none · Backup: none |
| [iface] S3 REST endpoint | Port 443 · HTTPS · **Access control: anonymous permitted** · Externally exposed: yes |
| Flow: GetObject | HTTPS · initiator = anonymous user · carries PII · no authentication |
| Flow: ListBucket | HTTPS · **enumeration-enabling** · should be explicitly denied |
| Trust boundary | Internet→AWS. Symmetric within AWS account. Only control at the crossing is the bucket policy. |

> 💡 **Bridge.** One data store holding three classifications is the single highest-leverage finding in this whole guide. It's why the fishbone in [05](05-other-model-types.md) puts "public + private data in one bucket" under root causes rather than treating it as one mitigation among many.

---

## 4.7 L1-B — Scenario A, Path 2: CloudFront in Front

```mermaid
flowchart LR
    subgraph TB1["🔴 Internet (untrusted)"]
        User(("Anonymous<br/>User"))
    end

    subgraph TB2["🟡 AWS Edge"]
        WAF{{"WAF Web ACL<br/>block element"}}
        CF["CloudFront<br/>Distribution"]
    end

    subgraph TB3["🟢 AWS Account (trusted)"]
        S3[("S3 Bucket<br/>OAC-restricted")]
        CT["CloudTrail"]
    end

    User -->|"▶init User · HTTPS"| WAF
    WAF -->|"rate-limited"| CF
    CF -->|"▶init CF · SigV4 via OAC"| S3
    S3 -.-> CT

    style TB1 fill:#3d1f1f,color:#fff
    style TB2 fill:#3d3319,color:#fff
    style TB3 fill:#1f3d2b,color:#fff
```

**The critical annotation:** OAC restricts CloudFront→S3, but it does **not** by itself close the S3 origin to the internet. Unless the bucket policy also carries an explicit condition tying access to the distribution ARN, an attacker simply skips the CDN entirely — bypassing WAF, rate limiting, and CloudFront logging in one move. That is attack-tree leaf 2.1 in [08](08-attack-trees-capec.md).

| Flow | Protocol | Auth | Initiator |
|---|---|---|---|
| User → WAF | HTTPS/TLS 1.2+ | none (by design) | User |
| WAF → CloudFront | internal | n/a | — |
| CloudFront → S3 | HTTPS + SigV4 | OAC signed request | CloudFront |
| *(hypothetical) User → S3 direct* | HTTPS | **should be denied** | User |

---

## 4.8 L1-C — Scenario B: Unintentional Exposure

The bucket was meant to be private. A control failed. Modeling the *intended* boundary next to the *actual* one is how you catch this class on paper.

```mermaid
flowchart LR
    subgraph TB1["🟢 Intended: VPC-only (trusted)"]
        App["Application<br/>Backend"]
    end

    subgraph TB2["🔴 Internet (untrusted)"]
        Attacker(("Anonymous<br/>User / Scanner"))
    end

    subgraph TB3["⚫ AWS Account — boundary FAILED"]
        S3[("S3 Bucket<br/>customer data")]
    end

    App -->|"▶init App · intended path · HTTPS"| S3
    Attacker -->|"UNINTENDED · control failure<br/>bucket policy / BPA / ACL"| S3

    style TB1 fill:#1f3d2b,color:#fff
    style TB2 fill:#3d1f1f,color:#fff
    style TB3 fill:#5c1a1a,color:#fff
```

**The three independent ways this boundary fails** (all must be closed — closing one is not enough):
1. Bucket policy with `Principal: "*"`
2. Block Public Access disabled at account or bucket level
3. Legacy ACL granting `AllUsers` or `AuthenticatedUsers` — note the latter means *any AWS account anywhere*, not just yours

---

## 4.9 L1-D — Full Current-State L1 (all paths, all prefixes)

The real system as it exists after the session in [03](03-session-facilitation.md) surfaced the avatar upload.

```mermaid
flowchart LR
    subgraph TB1["🔴 Internet (untrusted)"]
        User(("Anonymous<br/>User"))
        Customer(("Auth.<br/>Customer"))
    end

    subgraph TB2["🟡 AWS Edge"]
        WAF{{"WAF"}}
        CF["CloudFront"]
    end

    subgraph TB3["🟢 AWS Account (trusted)"]
        S3Pub[("prefix: /public/<br/>marketing assets")]
        S3Av[("prefix: /avatars/<br/>UGC · UNSCANNED")]
        S3Data[("prefix: /exports/<br/>PII + regulated")]
        Reader["Analytics Reader<br/>service"]
        CT["CloudTrail"]
        LOGS[("Log Bucket")]
    end

    subgraph TB4["🟠 CI/CD (semi-trusted, external)"]
        GHA["GitHub Actions"]
    end

    User -->|"▶init User"| WAF --> CF
    CF -->|"OAC"| S3Pub
    CF -->|"OAC"| S3Av
    Customer -->|"▶init Customer<br/>presigned PUT ⚠"| S3Av
    Reader -->|"▶init Reader<br/>List + Get · PII"| S3Data
    GHA -->|"▶init GHA · OIDC<br/>PutBucketPolicy ⚠"| S3Data

    S3Pub -.-> CT
    S3Av -.-> CT
    S3Data -.-> CT
    S3Pub -.-> LOGS

    style TB1 fill:#3d1f1f,color:#fff
    style TB2 fill:#3d3319,color:#fff
    style TB3 fill:#1f3d2b,color:#fff
    style TB4 fill:#3d2f19,color:#fff
    style S3Av fill:#5c1a1a,color:#fff
```

⚠ markers = open findings. See [A-findings-register.md](A-findings-register.md).

---

## 4.10 L1-E — Target-State L1 (after remediation)

Same system, drawn as it *should* look. Drawing the target state next to current state makes the remediation gap concrete and gives you something to verify against later.

```mermaid
flowchart LR
    subgraph TB1["🔴 Internet"]
        User(("Anonymous"))
        Customer(("Auth. Customer"))
    end

    subgraph TB2["🟡 AWS Edge"]
        WAF{{"WAF + rate limit"}}
        CF["CloudFront"]
    end

    subgraph TB3["🟢 Account A — Public"]
        BPub[("bucket: public-assets<br/>BPA on, no PII")]
    end

    subgraph TB4["🟠 Account B — UGC (isolated)"]
        Scan["Malware Scan<br/>+ Re-encode"]
        BUgc[("bucket: user-content")]
    end

    subgraph TB5["🔵 Account C — Regulated"]
        BData[("bucket: customer-exports<br/>CMK · Object Lock · versioned")]
        Reader["Analytics Reader"]
    end

    User --> WAF --> CF --> BPub
    CF --> BUgc
    Customer -->|"presigned PUT"| Scan -->|"re-encoded only"| BUgc
    Reader -->|"conditional read<br/>pinned versionId"| BData

    style TB1 fill:#3d1f1f,color:#fff
    style TB2 fill:#3d3319,color:#fff
    style TB3 fill:#1f3d2b,color:#fff
    style TB4 fill:#3d2f19,color:#fff
    style TB5 fill:#1f2f4d,color:#fff
```

**What changed and why:** three buckets in three accounts (blast-radius containment) · scan-and-re-encode gate before UGC is stored (kills T18) · CMK + Object Lock + versioning on regulated data (kills T12, enables F-07 fix) · conditional pinned reads (kills F-07).

---

## 4.11 L2-A — Inside the S3 Bucket (component decomposition)

Stop treating S3 as a black box. This is where the *order* of AWS's own evaluation becomes visible.

```mermaid
flowchart TD
    Req["Incoming Request"]
    subgraph S3Int["S3 Bucket — Internal Components"]
        BPA["Block Public Access<br/>enforcement"]
        Pol["Bucket Policy<br/>evaluation"]
        ACL["Legacy ACL<br/>evaluation ⚠"]
        Own["Object Ownership<br/>setting"]
        Enc["SSE encrypt/decrypt"]
        Ver["Versioning &<br/>Object Lock ⚠ OFF"]
        Log["Access log emitter"]
    end
    Data[("Object Data")]

    Req --> BPA --> Pol --> ACL --> Enc --> Data
    Own -.->|"if bucket-owner-enforced,<br/>ACLs disabled entirely"| ACL
    Data --> Ver
    Req --> Log

    style ACL fill:#5c1a1a,color:#fff
    style Ver fill:#5c1a1a,color:#fff
```

> 💡 **Bridge.** L2 surfaced a finding L1 could not: **legacy ACL evaluation exists at all.** Block Public Access *overrides* ACLs; setting Object Ownership to bucket-owner-enforced *removes* them. Those are different security postures, and only the second one is actually retiring the code path.

---

## 4.12 L2-B — Inside CloudFront

```mermaid
flowchart TD
    Req["Incoming Request"]
    subgraph CFInt["CloudFront — Internal Components"]
        WAFR["WAF rule groups"]
        Cache["Cache behaviors<br/>(path routing)"]
        Sig["Signed URL/Cookie<br/>validation"]
        OAC["Origin Access Control"]
    end
    Origin[("S3 Origin")]

    Req --> WAFR --> Cache --> Sig --> OAC --> Origin
```

**Watch for:** cache behaviors that route `/avatars/*` and `/public/*` to the same origin with the same policy · anything authenticated being cached · signed-URL validation applied to only some behaviors.

---

## 4.13 L2-C — The Analytics Reader Service

```mermaid
flowchart TD
    subgraph Reader["Analytics Reader — Internal"]
        List["1 · List objects<br/>in /exports/"]
        Manif["2 · Fetch + validate<br/>manifest.json"]
        Loop["3 · Loop: GetObject<br/>each file ⚠"]
        Parse["4 · Parse & load<br/>to warehouse"]
    end
    List --> Manif --> Loop --> Parse
    style Loop fill:#5c1a1a,color:#fff
```

The gap between step 2 and step 3 is finding **F-07**. A DFD shows the steps exist; it cannot show that minutes pass between them. That needs the sequence diagram in [05](05-other-model-types.md).

---

## 4.14 L3-A — AWS Policy Evaluation Logic

```mermaid
flowchart TD
    Start["Request arrives"]
    SCP["1 · Organization SCP"]
    BPA2["2 · Block Public Access"]
    RP["3 · Resource policy<br/>(bucket policy)"]
    IP["4 · Identity policy (IAM)"]
    PB["5 · Permission boundary"]
    ACL2["6 · Legacy ACL"]
    Deny{"Explicit Deny<br/>anywhere in 1–6?"}
    Allow["ALLOW"]
    Block["DENY"]

    Start --> SCP --> BPA2 --> RP --> IP --> PB --> ACL2 --> Deny
    Deny -->|"yes — overrides everything"| Block
    Deny -->|"no, and an explicit Allow exists"| Allow
    Deny -->|"no Allow found"| Block

    style Block fill:#5c1a1a,color:#fff
```

**Why this level matters:** it tells you *where* to place a control for it to be un-bypassable. An SCP denying `s3:PutBucketPublicAccessBlock` sits at layer 1 — above anything a compromised deploy role at layer 4 can reach. That's a design decision you cannot make from an L1 diagram.

---

## 4.15 L3-B — Policy Deployment Pipeline

```mermaid
flowchart TD
    Dev["Developer commits<br/>Terraform change"]
    PR["Pull request<br/>+ review ⚠ 4-eyes?"]
    Plan["terraform plan"]
    Scan["IaC security scan<br/>⚠ present?"]
    State[("Terraform state<br/>remote backend")]
    Role["CI/CD Deploy Role<br/>⚠ scope unverified"]
    Apply["terraform apply"]
    CT2["CloudTrail:<br/>PutBucketPolicy"]
    Alarm["EventBridge alarm<br/>⚠ configured?"]

    Dev --> PR --> Plan --> Scan --> State --> Role --> Apply --> CT2 --> Alarm

    style Role fill:#5c1a1a,color:#fff
```

This diagram *is* the finding for T15 (IaC drift) and T9 (deploy-role over-permission). Three question marks on one path is a story about how a bucket goes public without anyone deciding to make it public.

---

## 4.16 L3-C — Avatar Upload Flow (current vs. target)

**Current:**
```mermaid
flowchart LR
    C(("Customer")) -->|"request URL"| API["App API"]
    API -->|"presigned PUT<br/>⚠ TTL? scope?"| C
    C -->|"raw bytes · unvalidated"| S3[("/avatars/")]
    S3 -->|"served as-is"| CDN["CloudFront"]
    style S3 fill:#5c1a1a,color:#fff
```

**Target:**
```mermaid
flowchart LR
    C(("Customer")) -->|"request URL"| API["App API"]
    API -->|"presigned PUT<br/>5min TTL · 1 object"| C
    C -->|"raw bytes"| Quar[("quarantine bucket")]
    Quar --> Magic["magic-byte<br/>validation"]
    Magic --> Scan["malware scan"]
    Scan --> Reenc["decode + re-encode<br/>from raw pixels"]
    Reenc --> Clean[("/avatars/ · clean")]
    Clean --> CDN["CloudFront + CSP"]
    style Clean fill:#1f3d2b,color:#fff
```

The re-encode step is the one that actually defeats steganography: passthrough serving of original bytes is precisely what preserves a hidden payload.

---

## 4.17 Quality Checklist for Your Own DFDs

> 📘 **Theory: what makes a model "good."** Four properties: **Accurate** (no misleading info — if the team says "what is *that*?", something went wrong) · **Meaningful** (information, not just data) · **Representative** (matches either the design intent *or* the implementation — pick one and say which) · **Living** (revisited as the system changes; model "what is," not "what should be").

**Before you call a DFD done:**

- [ ] Complete diagram including deployment
- [ ] Every component labelled
- [ ] Every flow direction shown with arrows
- [ ] Main action each arrow represents is labelled
- [ ] Protocol labelled on each flow
- [ ] Trust boundaries and networks labelled
- [ ] Every component sits inside a trust boundary
- [ ] Initiator marked on each flow
- [ ] Personas described, with how access differs per persona
- [ ] Authentication steps labelled
- [ ] Authorization steps labelled
- [ ] Order of actions numbered where it matters
- [ ] **"Crown jewels" explicitly marked** — most sensitive data, most critical functionality
- [ ] Data classification per store and per flow
- [ ] Open questions marked with `?` rather than guessed
- [ ] Level of each diagram stated in its title

---

## 4.18 Common DFD Anti-Patterns

| Anti-pattern | Why it hurts | Fix |
|---|---|---|
| **Too much detail** | Participants disengage when they can't follow it; you get an architecture diagram, not a threat model | Key components only; split into more levels |
| **No trust boundaries** | Without them you can't tell which flows matter most | Every component in a boundary; STRIDE the crossings first |
| **Ambiguous flow direction** | Different readers infer different threats | Arrows + initiator marks |
| **Drawn by security alone** | Misses flows only engineers know about (like our avatar upload) | Build it live, with the team |
| **Uniform depth everywhere** | Wasted effort decomposing branches where nothing interesting lives | Go deep only where control decisions change |
| **Known-wrong info to look complete** | Produces false findings, or worse, silence in a critical region | Question marks are fine; inaccuracies aren't |
| **Never updated** | Becomes archaeology within one quarter | [14 · Continuous Threat Modeling](14-continuous-threat-modeling.md) |
| **Inconsistent symbol use** | Team stops trusting the notation | Agree house rules up front (§4.2) |

---

[← 03 Session Facilitation](03-session-facilitation.md) · [Contents](README.md) · [04a Actor Library →](04a-actor-library.md)
