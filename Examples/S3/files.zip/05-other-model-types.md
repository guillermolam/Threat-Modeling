[← 04a Actor Library](04a-actor-library.md) · [Contents](README.md) · [06 STRIDE →](06-stride.md)

# 05 · Model Types Beyond the DFD

---

## 5.1 Choosing the Right Model

> 📘 **Theory.** Use each model type for what it's suited to. DFDs describe **relationships**; sequence diagrams describe **ordering**; process flow diagrams describe **activity chains**; attack trees describe **attacker paths**; fishbone diagrams describe **root causes**.

| Model | Shows | Best for finding |
|---|---|---|
| **DFD** | Components and data relationships | Missing controls at boundaries, exposure, trust failures |
| **Sequence diagram** | Order of operations over time | **TOCTOU, race conditions, missing exception handling, controls applied inconsistently or suppressed** |
| **Process flow diagram** | Chain of activities/events | Business-process weaknesses, missing approval steps |
| **Attack tree** | Attacker goal decomposition | Exploit paths, and whether a mitigation actually closes a branch |
| **Fishbone (Ishikawa)** | Effect ← causes | Root causes, supply-chain and configuration-management weaknesses |

---

## 5.2 Sequence Diagrams — The Underused One

> 📘 **Theory.** Sequence diagrams come from UML. There's a live argument in the field that they may be **more important than DFDs** for threat modeling, because a DFD shows *that* data flows and *what* data, while a sequence diagram shows *how* and *in what order*. Business-logic flaws and protocol-handling errors are easier to find this way — and some are findable *only* this way.
>
> **Elements you need:** entities with lifelines · messages between them (solid arrowheads = synchronous/blocking; open = asynchronous; dashed = returns) · conditional logic inline as `[condition]` · time flowing top to bottom.
>
> **Good candidates to model:** authentication flows · authorization flows · anything involving a data store or asynchronous processing · any standard operating procedure spanning multiple entities.

### How to spot TOCTOU

> 📘 Look for a sequence where **one process interacts with the same data twice**, and **a different entity interacts with that data in between**. If the intervening access changes state, the second interaction operates on a stale premise.

### 🏢 Applied: the analytics export read path

```mermaid
sequenceDiagram
    participant R as Analytics Reader
    participant S3 as S3 /exports/ prefix
    participant A as Attacker (write-capable)

    R->>S3: ListObjects(prefix=/exports/)
    S3-->>R: object list + ETags
    R->>S3: GetObject(manifest.json)
    S3-->>R: manifest
    Note over R: ✅ TIME OF CHECK<br/>manifest validated
    A->>S3: PutObject(export_003.csv) — overwrite
    Note over S3,A: ⚠ Intervening write<br/>by a different entity
    R->>S3: GetObject(export_003.csv)
    S3-->>R: attacker-controlled content
    Note over R: ❌ TIME OF USE<br/>content treated as pre-validated
    R->>R: parse & load to warehouse
```

**Finding F-07.** Minutes elapse between validation and read on large exports. Any principal able to write to the prefix in that window supplies content the reader treats as vouched-for.

**Mitigations:**
- Validate **per object at time of use**, not once up front
- Conditional reads: `If-Match` against the ETag captured at check time, so a modified object *fails* rather than silently succeeding
- Enable versioning and read a **pinned `versionId`** instead of "latest"
- Structurally: no principal other than the writer service should hold `PutObject` on that prefix

> 💡 **Bridge.** Every prior version of this model had a complete, correct DFD of this system and never found F-07 — not because the DFD was drawn badly, but because **a DFD has no representation of time**. If you take one technique from this file, take this one.

### 🏢 A second sequence: presigned upload

```mermaid
sequenceDiagram
    actor C as Customer
    participant API as App API
    participant S3 as S3 /avatars/
    participant CDN as CloudFront

    C->>API: request upload URL
    API->>API: authorize user
    Note over API: ⚠ Is TTL bounded?<br/>Scoped to one object?
    API-->>C: presigned PUT URL
    Note over C: ⚠ URL now exists outside<br/>our control — can be<br/>forwarded, logged, screenshotted
    C->>S3: PUT raw bytes
    Note over S3: ⚠ No validation<br/>No scan · No re-encode
    S3-->>C: 200 OK
    CDN->>S3: GET (on later request)
    S3-->>CDN: original bytes, unchanged
    CDN-->>C: served from trusted domain
```

Three findings visible here that the DFD only hinted at: the URL's lifetime outside your control, the absence of any validation step, and — critically — that **the bytes served are byte-identical to the bytes uploaded**, which is the precise property steganographic staging depends on.

---

## 5.3 Process Flow Diagrams

> 📘 **Theory.** PFDs come from process and chemical engineering. They show the sequence and directionality of **operations** through a system — similar to sequence diagrams but higher-level, showing the activity chain rather than individual messages. Uncommon in threat modeling generally (ThreatModeler is the main tool built around them), but useful for **business-process** threat modeling, which is where they're genuinely strong.

### 🏢 Applied: the data-export business process

```mermaid
flowchart LR
    A["Analyst requests<br/>export"] --> B["Job generates<br/>export files"]
    B --> C["Files written<br/>to /exports/"]
    C --> D["Reader ingests<br/>to warehouse"]
    D --> E["Report produced"]
    E --> F["Files retained<br/>⚠ how long?"]
    style F fill:#5c1a1a,color:#fff
```

The PFD asks a question the DFD doesn't: **what happens at the end?** Nobody had defined retention for generated exports. A PII file that only needed to exist for one hour and instead exists forever is a real risk with no attacker in it at all.

---

## 5.4 Fishbone (Ishikawa) Diagrams

> 📘 **Theory.** Also called cause-and-effect diagrams, used for **root cause analysis**. Where attack trees run *forward* from an attacker goal, fishbone runs *backward* from an outcome. Build it by naming the effect, identifying primary causes, then the causes behind those.
>
> Particularly good for supply-chain analysis, configuration management, and process weaknesses — the failures that aren't "attacks" at all. They also make your DFDs better, because working out root causes tells you what to ask next.

### 🏢 Effect: "Customer data becomes publicly readable"

```mermaid
flowchart LR
    C1["<b>PROCESS</b><br/>• No pre-merge policy review<br/>• Console access allowed in prod<br/>• No drift detection cadence<br/>• No defined retention"] --> E
    C2["<b>TOOLING</b><br/>• BPA not enforced by SCP<br/>• No automated remediation<br/>• No Config rules deployed<br/>• No IaC security scanning"] --> E
    C3["<b>PEOPLE</b><br/>• Deploy role scope unverified<br/>• No separation of duties<br/>• Root-only AWS access<br/>• No access reviews"] --> E
    C4["<b>ARCHITECTURE</b><br/>• Public + UGC + PII in one bucket<br/>• Legacy ACLs not disabled<br/>• Predictable key naming<br/>• No integrity verification"] --> E
    E["<b>EFFECT</b><br/>Customer data<br/>publicly readable"]
    style E fill:#8b1a1a,color:#fff
```

> 💡 **Bridge.** The ARCHITECTURE branch contains the highest-leverage fix in this entire guide — separating classifications into distinct buckets. Fishbone surfaces it as a **root cause** rather than as one mitigation among thirty, which is a materially more useful framing than the attack tree gave it. Fixing a root cause collapses many findings at once; fixing a leaf collapses one.

### 🏢 Second fishbone: "Malicious content served from our domain"

```mermaid
flowchart LR
    D1["<b>INPUT HANDLING</b><br/>• No magic-byte validation<br/>• No size ceiling<br/>• Extension trusted"] --> F
    D2["<b>STORAGE</b><br/>• Bytes stored verbatim<br/>• No re-encode step<br/>• Shared bucket with trusted content"] --> F
    D3["<b>SERVING</b><br/>• Served from allow-listed domain<br/>• No CSP on rendering pages<br/>• Same CDN as trusted assets"] --> F
    D4["<b>DETECTION</b><br/>• No malware scanning<br/>• No file-size anomaly alerting<br/>• No content review"] --> F
    F["<b>EFFECT</b><br/>Malicious content<br/>staged & distributed<br/>from a trusted domain"]
    style F fill:#8b1a1a,color:#fff
```

Note that **SERVING** is the branch that turns an ordinary bad-upload problem into a serious one: the payload's value to an attacker comes from *your domain's reputation*, not from the file itself.

---

## 5.5 Using Them Together

```mermaid
flowchart TD
    DFD["<b>DFD</b><br/>What exists, what connects"] --> SEQ["<b>Sequence</b><br/>What happens when"]
    DFD --> PFD["<b>PFD</b><br/>What the process does end-to-end"]
    SEQ --> AT["<b>Attack Tree</b><br/>How an attacker gets there"]
    PFD --> AT
    AT --> FISH["<b>Fishbone</b><br/>Why it was possible at all"]
    FISH -.->|"root causes become<br/>architectural requirements"| DFD
    style FISH fill:#8957e5,color:#fff
```

The loop back matters: root causes identified in the fishbone should change the *target-state* DFD ([04 §4.10](04-dfd-library.md)), not just add tickets.

---

[← 04a Actor Library](04a-actor-library.md) · [Contents](README.md) · [06 STRIDE →](06-stride.md)
